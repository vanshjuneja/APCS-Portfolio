/*
 * Vansh Juneja
 * Main.java
 * Ms.Krasteva
 * 2018-10-12
 * This program displays an animation about desktop icons coming
 * to life and happy emotes coming out of a text file, and being
 * consumed by virus emotes from the trash bin
 */

// import statements
import java.awt.*; // colour libraries
import hsa.Console; // hsa.Console library
import java.lang.*; // Thread libraries

// MyCreation class
public class Main
{
  static hsa.Console c; // new static hsa.Console c
  
  
  // class constructor method
  public Main ()
  {
    c = new hsa.Console ("MyCreation -- Vansh J"); // set c as new hsa.Console
  }
  
  
  // background method
  public void background ()
  {
    Background b = new Background (c); // create new Background object b
  }
  
  
  // computerIcon method
  public void computerIcon ()
  {
    ComputerIcon o = new ComputerIcon (c); // create new ComputerIcon object o
    o.run (); // start animating ComputerIcon thread
  }
  
  
  // trashIcon method
  public void trashIcon ()
  {
    // delay before animating trash icon
    try
    {
      Thread.sleep (3000); // 3 second delay (3000ms)
    }
    catch (Exception e)
    {
    }
    TrashIcon r = new TrashIcon (c); // create new TrashIcon object r
    r.start (); // start animating trashIcon thread
    
    // joins with VirusEmote thread so that it only executes when TrashIcon thread is done
    try
    {
      r.join ();
    }
    catch (InterruptedException e)
    {
    }
  }
  
  
  // textIcon method
  public void textIcon ()
  {
    TextIcon t = new TextIcon (c); // create new TextIcon object t
    t.start (); // start animating textIcon thread
  }
  
  
  // happyEmote method
  public void happyEmote ()
  {
    HappyEmote h = new HappyEmote (c); // create new HappyEmote object h
    h.start (); // start animating HappyEmote thread
  }
  
  
  // danceEmote method
  public void danceEmote ()
  {
    DanceEmote d = new DanceEmote (c); // create new DanceEmote obejct d
    d.start (); // start animating DanceEmote thread
  }
  
  
  // virusEmote method
  public void virusEmote ()
  {
    VirusEmote v1 = new VirusEmote (c, 258); // create new VirusEmote object v
    v1.start (); // start animating VirusEmote thread via its first constructor
    VirusEmote v2 = new VirusEmote (c, 349, new Color (255, 197, 99)); // create new VirusEmote object v
    v2.start (); // start animating VirusEmote thread via its second constructor
    VirusEmote v3 = new VirusEmote (c, 440, new Color (250, 70, 255), 3000); // create new VirusEmote object v
    v3.start (); // start animating VirusEmote thread via its third constructor
    
    //joins with Conclusion thread so that it only executes when the VirusEmote thread is done
    try
    {
      v3.join ();
    }
    catch (InterruptedException e)
    {
    }
  }
  
  
  // conclusion method
  public void conclusion ()
  {
    Conclusion n = new Conclusion (c); // create new Conclusion object n
    n.start (); // start animating the Conclusion thread
  }
  
  
  // main method
  public static void main (String[] args)
  {
    Main m = new Main (); // create new myCreation obejct m
    // execute object creation methods
    m.background ();
    m.computerIcon ();
    m.textIcon ();
    m.happyEmote ();
    m.danceEmote ();
    m.trashIcon ();
    m.virusEmote ();
    m.conclusion ();
  }
}
