/*
    * Vansh Juneja
    * TextIcon.java
    * Ms.Krsateva
    * 2018-10-12
    * This program displays the background of the MyCreation aniation that repeatedly animates left and right to simulate shaking
*/


// import statements
import java.awt.*; // colour libraries
import hsa.Console; // hsa.Console library
import java.lang.*; // Thread libraries

// MyCreation class
public class TextIcon extends Thread
{
    private hsa.Console c; // new static hsa.Console c

    // text method
    public void text ()
    {
 // variables
 int x = 0; // relative x-value
 
 // colors
 Color paperGrey = new Color (245, 245, 245);
 Color paperCream = new Color (220, 215, 180);
 Color backBlue = new Color (200, 255, 255);
 
 // draw text icon
 for (int i = 10 ; i <= 250 ; i++)
 {
     // animate icon moving to the right half the time
     if (i / 10 % 2 == 1)
     {
  x += 1;
     }
     // animate icon moving to the left the other half of the time
     else
     {
  x -= 1;
     }

     //erase
     c.setColor (backBlue);
     c.fillRect (4 + x, 185, 43, 60);

     // document
     c.setColor (paperGrey);
     c.fillRect (5 + x, 185, 25, 50);
     c.fillRect (5 + x, 200, 40, 35);
     c.setColor (paperCream);
     int paperFoldX[] = {30 + x, 30 + x, 45 + x};
     int paperFoldY[] = {185, 200, 200};
     c.fillPolygon (paperFoldX, paperFoldY, 3);
     c.setColor (Color.black);
     // outline
     c.drawLine (30 + x, 185, 5 + x, 185);
     c.drawLine (5 + x, 185, 5 + x, 235);
     c.drawLine (5 + x, 235, 45 + x, 235);
     c.drawLine (45 + x, 235, 45 + x, 200);
     c.drawLine (45 + x, 200, 30 + x, 185);
     c.drawLine (45 + x, 200, 30 + x, 200);
     c.drawLine (30 + x, 200, 30 + x, 185);
     // text lines
     c.drawLine (10 + x, 190, 30 + x, 190);
     c.drawLine (10 + x, 192, 30 + x, 192);
     c.drawLine (10 + x, 194, 30 + x, 194);
     c.drawLine (10 + x, 196, 30 + x, 196);
     c.drawLine (10 + x, 207, 41 + x, 207);
     c.drawLine (14 + x, 210, 41 + x, 210);
     c.drawLine (10 + x, 215, 41 + x, 215);
     c.drawLine (14 + x, 218, 41 + x, 218);
     c.drawLine (23 + x, 225, 40 + x, 225);
     c.drawLine (21 + x, 228, 41 + x, 228);
     // image
     c.drawRect (9 + x, 220, 10, 10);
     c.drawOval (10 + x, 221, 3, 3);
     c.drawOval (15 + x, 221, 3, 3);
     c.drawArc (11 + x, 222, 5, 6, 200, 160);
     //text
     c.setColor (Color.black);
     c.setFont (new Font ("Arial", 1, 8));
     c.drawString ("Emotes.txt", 6 + x, 244);

     // delay
     try
     {
  Thread.sleep (10); // 10ms pause between frames of animation
     }
     catch (Exception e)
     {
     }
 }
    }



    // class constructor method
    public TextIcon (hsa.Console con)
    {
 c = con; // private hsa.Console c is set as passsed hsa.Console arguement con
    }


    // run method
    public void run ()
    {
 text (); // execute text method
    }
}
