/*
    * Vansh Juneja
    * VirusEmote.java
    * Ms.Krsateva
    * 2018-10-12
    * This class displays the virus emote of the MyCreation animation covering the entire screen behind it with blue
*/


// import statements
import java.awt.*; // colour libraries
import hsa.Console; // hsa.Console library
import java.lang.*; // Thread libraries

// MyCreation class
public class VirusEmote extends Thread
{
    // variables
    private hsa.Console c; // new static hsa.Console c
    int stop; // # of pixels in to the screen from the left should the virusEmote instance will stop
    Color bodyClr; // color of the body of the virusEmote istance
    int delay; // how much of a delay should there be before the virusEmote appears, from being declared

    // virus emote method
    public void virusEmote ()
    {
 // variables
 int x = -10; // relative x-value
 int y = 109; // relative y-value
 
 // colors
 Color mouthGreen = new Color (120, 175, 115);
 Color flagTipYellow = new Color (255, 212, 114);
 Color flagRed = new Color (255, 0, 0);
 Color backBlue = new Color (0, 0, 255);
 
 // delay
 try
 {
     Thread.sleep (delay); // delay number of ms before starting virusEmote animtion
 }
 catch (Exception e)
 {
 }
 
 // draw virusEmote
 for (int i = -10 ; i <= stop + 3100 ; i++)
 {
     // animation direction
     if (i <= 100 + stop)
     {
  x += 1; // move to the right
     }
     if (i > stop + 100 && i < stop + 153)
     {
  y -= 1; // move up
     }
     if (i >= stop + 153 && i < stop + 520)
     {
  x -= 1; // move to the left
     }
     if (i > stop + 520 && i < stop + 573)
     {
  y -= 1; // move up
     }
     if (i >= stop + 573 && i < stop + 941)
     {
  x += 1; // move to the right
     }
     if (i > stop + 941 && i < stop + 946)
     {
  y -= 1; // move up
     }
     if (i >= stop + 946 && i < stop + 1314)
     {
  x -= 1; // move to the left
     }
     if (i > stop + 1314 && i < stop + 1475)
     {
  y += 1; // move down
     }
     if (i >= stop + 1475 && i < stop + 1843)
     {
  x += 1; // move to the right
     }
     if (i > stop + 1843 && i < stop + 2132)
     {
  y += 1; // move down
     }
     if (i > stop + 2132 && i < stop + 2405)
     {
  x -= 1; // move to the left
     }
     if (i > stop + 2405 && i < stop + 2642)
     {
  y -= 1; // move up
     }
     if (i > stop + 2642 && i < stop + 2755)
     {
  x -= 1; // move to the left
     }
     if (i > stop + 2755 && i < stop + 3100)
     {
  y += 1; // move down
     }
     
     // erase
     c.setColor (backBlue);
     c.fillRect (8 + x, -1 + y, 92, 52);

     // body fill
     c.setColor (bodyClr);
     c.fillArc (9 + x, 11 + y, 6, 32, 90, 180);
     c.fillArc (76 + x, 12 + y, 5, 30, 270, 180);
     c.fillRect (12 + x, 12 + y, 66, 30);
     // body outline
     c.setColor (Color.black);
     c.drawArc (9 + x, 12 + y, 5, 30, 90, 180);
     c.drawArc (76 + x, 12 + y, 4, 30, 270, 180);
     c.drawLine (12 + x, 12 + y, 78 + x, 12 + y);
     c.drawLine (12 + x, 42 + y, 78 + x, 42 + y);
     // legs
     c.drawLine (34 + x, 42 + y, 34 + x, 46 + y); // left
     c.drawLine (68 + x, 42 + y, 68 + x, 46 + y); // right
     // shoe fills
     c.setColor (Color.white);
     c.fillRect (32 + x, 46 + y, 6, 3); // left
     c.fillRect (66 + x, 46 + y, 6, 3); // right
     // shoe outlines
     c.setColor (Color.black);
     c.drawRect (32 + x, 46 + y, 6, 3); // left
     c.drawRect (66 + x, 46 + y, 6, 3); // right
     // mouth fills
     c.setColor (mouthGreen);
     c.fillRect (36 + x, 24 + y, 30, 18);
     // mouth outlines
     c.setColor (Color.black);
     c.drawRect (36 + x, 24 + y, 30, 18);
     // mouth lines
     c.drawLine (42 + x, 24 + y, 36 + x, 30 + y);
     c.drawLine (48 + x, 24 + y, 36 + x, 36 + y);
     c.drawLine (54 + x, 24 + y, 36 + x, 42 + y);
     c.drawLine (60 + x, 24 + y, 42 + x, 42 + y);
     c.drawLine (66 + x, 24 + y, 48 + x, 42 + y);
     c.drawLine (66 + x, 30 + y, 54 + x, 42 + y);
     c.drawLine (66 + x, 36 + y, 60 + x, 42 + y);
     // eye outlines
     c.drawOval (32 + x, 14 + y, 8, 8); // left
     c.drawOval (69 + x, 14 + y, 8, 8); // right
     // pupil fills
     c.fillOval (33 + x, 15 + y, 7, 7); // left
     c.fillOval (70 + x, 15 + y, 7, 7); // right
     // arm lines
     c.drawArc (-3 + x, -6 + y, 30, 36, 270, 80); // left
     c.drawArc (69 + x, -6 + y, 30, 36, 270, 80); // right
     // flag
     c.drawLine (48 + x, 12 + y, 48 + x, 3 + y); // pole
     c.setColor (flagRed);
     c.fillRect (48 + x, 3 + y, 12, 4); // flag fill
     c.setColor (Color.black);
     c.drawRect (48 + x, 3 + y, 12, 4); // flag outline
     c.setColor (flagTipYellow);
     c.fillOval (47 + x, 0 + y, 4, 4); // pole tip fill
     c.setColor (Color.black);
     c.drawOval (47 + x, 0 + y, 3, 3); // pole tip outline
     // "virus" text
     c.setFont (new Font ("Arial", 1, 7));
     c.drawString ("VIRUS", 43 + x, 21 + y);

     // delay
     try
     {
  Thread.sleep (5); // pause of 1ms between each frame in animation
     }
     catch (Exception e)
     {
     }
 }
    }


    // class overloaded constructor method 1
    public VirusEmote (hsa.Console con, int stp)
    {
 c = con; // private hsa.Console c is set as passsed hsa.Console arguement con
 stop = stp; // set stop variable as passed as arguement to constructor
 delay = 0; // set delay to default
 bodyClr = new Color (145, 195, 140); // set body color to default
    }


    // class overloaded constructor method 2
    public VirusEmote (hsa.Console con, int stp, Color  clr)
    {
 c = con; // private hsa.Console c is set as passsed hsa.Console arguement con
 stop = stp; // set stop variable as passed as arguement to constructor
 delay = 1500; // set delay as passed as arguement to constructor
 bodyClr = clr; // set body color to default
    }


    // class overloaded constructor method 3
    public VirusEmote (hsa.Console con, int stp, Color clr, int dla)
    {
 c = con; // private hsa.Console c is set as passsed hsa.Console arguement con
 stop = stp; // set stop variable as passed as arguement to constructor
 delay = dla; // set delay as passed as arguement to constructor
 bodyClr = clr; // set flag color variable as passed as arguement to constructor
    }


    // run method
    public void run ()
    {
 virusEmote (); // execute virusEmote method
    }
}
