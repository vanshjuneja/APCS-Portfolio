package hsa;

import java.awt.Graphics;

public abstract class Paintable
{
    public abstract void paint (Graphics g);
} // Paintable interface
