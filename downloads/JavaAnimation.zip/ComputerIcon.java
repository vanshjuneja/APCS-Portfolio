/*
    * Vansh Juneja
    * ComputerIcon.java
    * Ms.Krsateva
    * 2018-10-12
    * This class draws and animates the desktop computer icon which repeatedly animates left and right to give a shaking effect
*/


// import statements
import java.awt.*; // colour libraries
import hsa.Console; // hsa.Console library
import java.lang.*; // Thread libraries

// MyCreation class
public class ComputerIcon implements Runnable
{
    private hsa.Console c; // new static hsa.Console c

    // computer method
    public void computer ()
    {
 // variables
 int x = 0; // relative x-value

 // colors
 Color screenBlue = new Color (185, 215, 255);
 Color standGrey = new Color (165, 165, 165);
 Color backBlue = new Color (200, 255, 255);

 // draw computer icon
 for (int i = 10 ; i <= 200 ; i++)
 {
     // animate icon moving to the right half the time
     if (i / 10 % 2 == 1)
     {
  x += 1;
     }
     // animate icon moving to the left the other half of the time
     else
     {
  x -= 1;
     }

     // erase
     c.setColor (backBlue);
     c.fillRect (-1 + x, 5, 58, 72);

     // stand
     c.setColor (standGrey);
     c.fillArc (28 + x, 40, 17, 17, 320, 180);
     c.setColor (Color.black);
     c.drawLine (36 + x, 37, 38 + x, 43);
     c.drawLine (43 + x, 39, 42 + x, 44);
     // screen and screen border
     int screenAx[] = {15 + x, 52 + x, 52 + x, 15 + x};
     int screenAy[] = {5, 18, 43, 30};
     int screenBx[] = {17 + x, 50 + x, 50 + x, 17 + x};
     int screenBy[] = {8, 20, 40, 28};
     // screen border
     c.setColor (Color.black);
     c.fillPolygon (screenAx, screenAy, 4);
     // screen
     c.setColor (screenBlue);
     c.fillPolygon (screenBx, screenBy, 4);
     // windows icon
     c.setColor (Color.white);
     c.fillRect (32 + x, 20, 6, 4);
     c.fillRect (40 + x, 20, 6, 4);
     c.fillRect (32 + x, 26, 6, 4);
     c.fillRect (40 + x, 26, 6, 4);
     // keyboard
     c.setColor (standGrey);
     int keyboardX[] = {15 + x, 0 + x, 30 + x, 45 + x};
     int keyboardY[] = {48, 53, 63, 58};
     c.fillPolygon (keyboardX, keyboardY, 4);
     // mouse
     c.fillOval (45 + x, 60, 9, 7);
     //text
     c.setColor (Color.black);
     c.setFont (new Font ("Arial", 1, 8));
     c.drawString ("My Computer", 5 + x, 75);

     // delay
     try
     {
  Thread.sleep (10); // 10ms pause between frames of animation
     }
     catch (Exception e)
     {
     }
 }
    }


    // class constructor method
    public ComputerIcon (hsa.Console con)
    {
 c = con; // private hsa.Console c is set as passsed hsa.Console arguement con
    }


    // Thread run method
    public void run ()
    {
 computer (); // execute computer method 
    }
}


