/*
    * Vansh Juneja
    * Background.java
    * Ms.Krasteva
    * 2018-10-12
    * This program displays the background of the MyCreation aniation
*/


// import statements
import java.awt.*; // colour libraries
import hsa.Console; // hsa.Console library
import java.lang.*; // Thread libraries

// MyCreation class
public class Background
{
    private hsa.Console c; // new static hsa.Console c

    // draw method
    public void draw ()
    {
 // colour variables
 Color backBlue = new Color (200, 255, 255);
 Color backGreen = new Color (175, 215, 125);
 Color backYellow = new Color (245, 245, 165);
 Color taskbarGrey1 = new Color (115, 115, 115);
 Color taskbarGrey2 = new Color (150, 150, 150);
 Color taskbarGrey3 = new Color (130, 130, 130);
 Color explorerIconBrown1 = new Color (190, 150, 65);
 Color explorerIconBrown2 = new Color (255, 255, 65);
 Color explorerIconBrown3 = new Color (255, 220, 150);
 Color spotifyIconGreen = new Color (100, 200, 100);
 Color mailIconBlue = new Color (155, 250, 220);
 Color screenBlue = new Color (185, 215, 255);
 Color standGrey = new Color (165, 165, 165);
 Color grey1 = new Color (230, 230, 230);
 Color grey2 = new Color (200, 200, 200);
 Color grey3 = new Color (130, 130, 130);
 Color trashRed = new Color (255, 160, 125);
 Color trashBlue = new Color (55, 95, 150);
 Color trashGreen = new Color (146, 219, 142);
 Color trashOrange = new Color (225, 165, 70);
 Color trashPurple = new Color (210, 125, 240);
 Color trashPink = new Color (250, 190, 230);
 Color paperGrey = new Color (245, 245, 245);
 Color paperCream = new Color (220, 215, 180);


 // draw desktop wallpaper
 // sky
 c.setColor (backBlue);
 for (int i = 0 ; i <= 480 ; i++)
 {
     c.drawRect (0, 0, 640, i);
 }
 // hills
 c.setColor (backGreen);
 for (int i = 0 ; i <= 500 ; i++)
 {
     c.drawOval (400 + i / 2, 330 + i / 2, 580, 500 - i); // right hill
     c.drawOval (-410 + i / 2, 337 + i / 2, 900, 500 - i); // left hill
 }
 // sun
 c.setColor (backYellow);
 for (int i = 0 ; i <= 200 ; i++)
 {
     c.drawOval (549 + i / 2, -90 + i / 2, 200, 200 - i);
 }
 // sun rays
 c.drawLine (489, 16, 540, 16);
 c.drawLine (560, 70, 530, 100);
 c.drawLine (631, 120, 631, 171);
 // taskbar
 for (int i = 0 ; i <= 40 ; i++)
 {
     // main bar
     c.setColor (taskbarGrey1);
     c.drawRect (0, 460, 640, i);
     // desktop peek button (right side)
     c.setColor (taskbarGrey2);
     c.drawRect (624, 460, 16, i);
 }
 //time
 c.setFont (new Font ("Arial", 1, 14));
 c.setColor (Color.white);
 c.drawString ("8:42 PM", 565, 476);
 c.drawString ("2018-10-11", 547, 494);
 //wifi symbol
 for (int i = 0 ; i <= 3 ; i++)
 {
     c.drawOval (518 + i / 2, 489 + i / 2, 3 - i, 3 - i);
     c.drawArc (512, 483, 12 + i, 12 + i, 90, 110);
     c.drawArc (507, 479, 19 + i, 19 + i, 90, 110);
     c.drawArc (500, 473, 27 + i, 27 + i, 90, 110);
 }
 // windows icon back
 c.setColor (taskbarGrey3);
 for (int i = 0 ; i <= 40 ; i++)
 {
     c.drawRect (0, 460, i, 500);
 }
 // windows icon
 c.setColor (Color.white);
 for (int i = 0 ; i <= 11 ; i++)
 {
     c.drawRect (8, 469, 11, i);
     c.drawRect (8, 482, 11, i);
     c.drawRect (21, 469, 11, i);
     c.drawRect (21, 482, 11, i);
 }
 // explorer icon
 // folder back
 c.setColor (explorerIconBrown1);
 for (int i = 0 ; i <= 30 ; i++)
 {
     c.drawRect (59, 465, 31, i);
 }
 // inner document
 c.setColor (explorerIconBrown2);
 for (int i = 0 ; i <= 12 ; i++)
 {
     c.drawRect (82, 475, i, 20);
 }
 // folder front
 c.setColor (explorerIconBrown3);
 for (int i = 0 ; i <= 25 ; i++)
 {
     c.drawRect (55, 470, 31, i);
 }
 // spotify icon
 // green back
 c.setColor (spotifyIconGreen);
 for (int i = 0 ; i <= 30 ; i++)
 {
     c.drawOval (119 + i / 2, 465 + i / 2, 30 - i, 30 - i);
 }
 // sound waves
 c.setColor (Color.black);
 for (int i = 0 ; i < 3 ; i++)
 {
     c.drawArc (123, 471 + i, 22, 13 - i, 0, 180);
     c.drawArc (125, 477 + i, 18, 11 - i, 0, 180);
     c.drawArc (127, 483 + i, 13, 7 - i, 0, 180);
 }
 // email icon
 c.setColor (mailIconBlue);
 for (int i = 0 ; i <= 17 ; i++)
 {
     // bottom left triangle
     int x1[] = {164, 164, 164 + i};
     int y1[] = {471, 492, 492};
     c.drawPolygon (x1, y1, 3);
     //bottom right triangle
     int x2[] = {198, 198, 198 - i};
     int y2[] = {471, 492, 492};
     c.drawPolygon (x2, y2, 3);
 }
 // top triangle
 for (int i = 0 ; i <= 32 ; i++)
 {
     int x3[] = {165, 181, 165 + i};
     int y3[] = {469, 489, 469};
     c.drawPolygon (x3, y3, 3);
 }

 // static computer icon
 // stand
 c.setColor (standGrey);
 for (int i = 0 ; i <= 17 ; i++)
 {
     c.drawArc (36 - i / 2, 48 - i / 2, i, i, 320, 180);
 }
 c.setColor (Color.black);
 c.drawLine (36, 37, 38, 43);
 c.drawLine (43, 39, 42, 44);
 // screen and screen border
 int screenAx[] = {15, 52, 52, 15};
 int screenBx[] = {17, 50, 50, 17};
 c.setColor (Color.black);
 for (int i = 0 ; i <= 25 ; i++)
 {
     // polygon array coordinates
     int screenAy[] = {5, 18, 43 - i, 30 - i};
     // screen border
     c.drawPolygon (screenAx, screenAy, 4);
 }
 c.setColor (screenBlue);
 for (int i = 0 ; i <= 21 ; i++)
 {
     // polygon array coordinates
     int screenBy[] = {8, 20, 40 - i, 28 - i};
     // screen
     c.drawPolygon (screenBx, screenBy, 4);
 }
 // windows icon
 c.setColor (Color.white);
 for (int i = 0 ; i <= 4 ; i++)
 {
     c.drawRect (32, 20, 6, 0 + i);
     c.drawRect (40, 20, 6, 0 + i);
     c.drawRect (32, 26, 6, 0 + i);
     c.drawRect (40, 26, 6, 0 + i);
 }
 // keyboard
 c.setColor (standGrey);
 for (int i = 0 ; i <= 15 ; i++)
 {
     c.drawLine (15 - i, 48 + i / 3, 45 - i, 58 + i / 3);
 }
 // mouse
 for (int i = 0 ; i <= 9 ; i++)
 {
     c.drawOval (45 + i / 2, 60, 9 - i, 7);
 }
 //text
 c.setColor (Color.black);
 c.setFont (new Font ("Arial", 1, 8));
 c.drawString ("My Computer", 5, 75);

 // static trash icon
 // bin back
 c.setColor (grey3);
 for (int i = 0 ; i <= 350 ; i++)
 {
     int binShapeCx[] = {4 + i / 10, 39, 59, 24 + i / 10};
     int binShapeCy[] = {111 + i / 35, 121, 116, 106 + i / 35};
     c.drawPolygon (binShapeCx, binShapeCy, 4);
 }
 // trash
 c.setColor (trashGreen);
 for (int i = 0 ; i <= 12 ; i++)
 {
     c.drawOval (23 + i / 2, 112 + i / 2, 12 - i, 12 - i);
 }
 c.setColor (trashRed);
 for (int i = 0 ; i <= 13 ; i++)
 {
     c.drawOval (15 + i / 2, 110 + i / 2, 13 - i, 13 - i);
 }
 c.setColor (trashBlue);
 for (int i = 0 ; i <= 7 ; i++)
 {
     c.drawRect (17, 115, 23, 7 - i);
 }
 c.setColor (trashOrange);
 for (int i = 0 ; i <= 7 ; i++)
 {
     c.drawOval (38 + i / 2, 110 + i / 2, 7 - i, 7 - i);
 }
 c.setColor (trashPink);
 for (int i = 0 ; i <= 4 ; i++)
 {
     c.drawRect (39, 117, 4 - i, 10);
 }
 c.setColor (trashPurple);
 for (int i = 0 ; i <= 7 ; i++)
 {
     c.drawRect (43, 115, 7 - i, 10);
 }
 //bin front
 c.setColor (grey1);
 for (int i = 0 ; i <= 1400 ; i++)
 {
     int binShapeAx[] = {5 + i / 40, 10 + i / 56, 35, 40};
     int binShapeAy[] = {110 + i / 140, 152 + i / 175, 160, 120};
     c.drawPolygon (binShapeAx, binShapeAy, 4);
 }
 c.setColor (grey2);
 for (int i = 0 ; i <= 40 ; i++)
 {
     int binShapeBx[] = {35 + i / 8, 40, 60, 50 + i / 4};
     int binShapeBy[] = {160 - i, 120, 115, 155 - i};
     c.drawPolygon (binShapeBx, binShapeBy, 4);
 }
 // face
 c.setColor (Color.black);
 for (int i = 0 ; i <= 5 ; i++)
 {
     c.drawOval (15 + i / 2, 125 + i / 2, 5 - i, 5 - i);
     c.drawOval (25 + i / 2, 125 + i / 2, 5 - i, 5 - i);
 }
 c.drawArc (17, 136, 9, 8, 0, 180);
 //text
 c.setColor (Color.black);
 c.setFont (new Font ("Arial", 1, 8));
 c.drawString ("Trash", 18, 169);

 // static text icon
 // document
 c.setColor (paperGrey);
 for (int i = 0 ; i <= 25 ; i++)
 {
     c.drawRect (5, 185, 25 - i, 50);
 }
 for (int i = 0 ; i <= 35 ; i++)
 {
     c.drawRect (5, 200, 40, 35 - i);
 }
 c.setColor (paperCream);

 for (int i = 0 ; i <= 15 ; i++)
 {
     int paperFoldX[] = {30, 30, 45-i};
     int paperFoldY[] = {185, 200, 200};
     c.drawPolygon (paperFoldX, paperFoldY, 3);
 }
 c.setColor (Color.black);
 // outline
 c.drawLine (30, 185, 5, 185);
 c.drawLine (5, 185, 5, 235);
 c.drawLine (5, 235, 45, 235);
 c.drawLine (45, 235, 45, 200);
 c.drawLine (45, 200, 30, 185);
 c.drawLine (45, 200, 30, 200);
 c.drawLine (30, 200, 30, 185);
 // text lines
 c.drawLine (10, 190, 30, 190);
 c.drawLine (10, 192, 30, 192);
 c.drawLine (10, 194, 30, 194);
 c.drawLine (10, 196, 30, 196);
 c.drawLine (10, 207, 41, 207);
 c.drawLine (14, 210, 41, 210);
 c.drawLine (10, 215, 41, 215);
 c.drawLine (14, 218, 41, 218);
 c.drawLine (23, 225, 40, 225);
 c.drawLine (21, 228, 41, 228);
 // image
 c.drawRect (9, 220, 10, 10);
 c.drawOval (10, 221, 3, 3);
 c.drawOval (15, 221, 3, 3);
 c.drawArc (11, 222, 5, 6, 200, 160);
 //text
 c.setColor (Color.black);
 c.setFont (new Font ("Arial", 1, 8));
 c.drawString ("Emotes.txt", 6, 244);
    }


    // class constructor method
    public Background (hsa.Console con)
    {
 c = con; // private hsa.Console c is set as passsed hsa.Console arguement con
 draw (); // execute draw method
    }
}
