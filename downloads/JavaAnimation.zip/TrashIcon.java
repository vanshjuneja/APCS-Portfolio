/*
    * Vansh Juneja
    * TrashIcon.java
    * Ms.Krsateva
    * 2018-10-12
    * This class displays the trashcan icon in the MyCreation aniation

*/


// import statements
import java.awt.*; // colour libraries
import hsa.Console; // hsa.Console library
import java.lang.*; // Thread libraries

// MyCreation class
public class TrashIcon extends Thread
{
    private hsa.Console c; // new static hsa.Console c

    // trash method
    public void trash ()
    {
 // variables
 int x = 0; // relative x-value

 // colors
 Color grey1 = new Color (230, 230, 230);
 Color grey2 = new Color (200, 200, 200);
 Color grey3 = new Color (130, 130, 130);
 Color black = new Color (0, 0, 0);
 Color trashRed = new Color (255, 160, 125);
 Color trashBlue = new Color (55, 95, 150);
 Color trashGreen = new Color (146, 219, 142);
 Color trashOrange = new Color (225, 165, 70);
 Color trashPurple = new Color (210, 125, 240);
 Color trashPink = new Color (250, 190, 230);
 Color backBlue = new Color (200, 255, 255);

 // draw trash icon
 for (int i = 10 ; i <= 200 ; i++)
 {
     // animate icon moving to the right half the time
     if (i / 10 % 2 == 1)
     {
  x += 1;
     }
     // animate icon moving to the left the other half of the time
     else
     {
  x -= 1;
     }

     // erase
     c.setColor (backBlue);
     c.fillRect (4 + x, 105, 57, 65);

     // bin arrays
     int binShapeAx[] = {5 + x, 10 + x, 35 + x, 40 + x};
     int binShapeAy[] = {110, 152, 160, 120};
     int binShapeBx[] = {35 + x, 40 + x, 60 + x, 50 + x};
     int binShapeBy[] = {160, 120, 115, 155};
     int binShapeCx[] = {5 + x, 40 + x, 60 + x, 25 + x};
     int binShapeCy[] = {110, 120, 115, 105};
     // bin back
     c.setColor (grey3);
     c.fillPolygon (binShapeCx, binShapeCy, 4);
     // trash
     c.setColor (trashGreen);
     c.fillOval (23 + x, 112, 12, 12);
     c.setColor (trashRed);
     c.fillOval (15 + x, 110, 13, 13);
     c.setColor (trashBlue);
     c.fillRect (17 + x, 115, 23, 7);
     c.setColor (trashOrange);
     c.fillOval (38 + x, 110, 7, 7);
     c.setColor (trashPink);
     c.fillRect (39 + x, 117, 4, 10);
     c.setColor (trashPurple);
     c.fillRect (43 + x, 115, 7, 10);
     //bin front
     c.setColor (grey1);
     c.fillPolygon (binShapeAx, binShapeAy, 4);
     c.setColor (grey2);
     c.fillPolygon (binShapeBx, binShapeBy, 4);
     // face
     c.setColor (black);
     c.fillOval (15 + x, 125, 5, 5);
     c.fillOval (25 + x, 125, 5, 5);
     c.drawArc (17 + x, 136, 9, 8, 0, 180);
     //text
     c.setColor (black);
     c.setFont (new Font ("Arial", 1, 8));
     c.drawString ("Trash", 18 + x, 169);

     // delay
     try
     {
  Thread.sleep (10); // 10ms pause between frames of animation
     }
     catch (Exception e)
     {
     }
 }
    }


    // class constructor method
    public TrashIcon (hsa.Console con)
    {
 c = con; // private hsa.Console c is set as passsed hsa.Console arguement con
    }


    // Thread run method
    public void run ()
    {
 trash (); // execute trash method
    }
}
